from django.shortcuts import render
from django.core.mail import send_mail
from django.shortcuts import redirect
# Create your views here.

def home_page(request):
    if request.method=="GET":
        return render(request,'index.html',)



def contact(request):
    if request.method=="POST":



        to = request.POST['email']
        msg="This Person want to contact you"+to
        send_mail('Portfolio!!',msg,to,['princesingwal@gmail.com','abhinavsingwal@gmail.com'],)
        print(request.POST)
        return redirect('home_page')